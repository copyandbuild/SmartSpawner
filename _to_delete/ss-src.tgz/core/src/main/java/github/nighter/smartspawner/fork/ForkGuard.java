package github.nighter.smartspawner.fork;

import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Single entry point the upstream classes call into.
 * <p>
 * Every upstream touch is one line calling a method here, so an upstream
 * {@code git pull} can only ever conflict on that single line.
 */
public final class ForkGuard {

    private ForkGuard() {
    }

    // --- WorldGuard region flags -------------------------------------------

    public static boolean canUse(Player player, Location location) {
        return ForkFlags.test(player, location, ForkFlags.USE);
    }

    public static boolean canPlace(Player player, Location location) {
        return ForkFlags.test(player, location, ForkFlags.PLACE);
    }

    public static boolean canBreak(Player player, Location location) {
        return ForkFlags.test(player, location, ForkFlags.BREAK);
    }

    public static boolean canStack(Player player, Location location) {
        return ForkFlags.test(player, location, ForkFlags.STACK);
    }

    public static boolean canSell(Player player, Location location) {
        if (ForkConfig.get().isBlockSellWhileAfk() && AfkService.isAfk(player)) {
            return false;
        }
        return ForkFlags.test(player, location, ForkFlags.SELL);
    }

    // --- Loot generation ----------------------------------------------------

    /**
     * Region side of the generation check: is loot generation allowed at all
     * at this spawner location?
     */
    public static boolean canGenerate(Location spawnerLocation) {
        return ForkFlags.test(spawnerLocation, ForkFlags.GENERATE);
    }

    /**
     * Player side of the generation check: does this player keep spawners
     * running? AFK players do not, which replaces the old external
     * NuviraMCSpawner plugin.
     */
    public static boolean countsAsActive(Player player) {
        if (player == null) {
            return false;
        }
        if (!ForkConfig.get().isIgnoreAfkPlayers()) {
            return true;
        }
        return !AfkService.isAfk(player);
    }

    /** Called from the fork reload path. */
    public static void invalidate() {
        ForkConfig.invalidate();
        AfkService.invalidate();
    }
}
