package github.nighter.smartspawner.fork;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.association.RegionAssociable;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.registry.FlagConflictException;
import com.sk89q.worldguard.protection.flags.registry.FlagRegistry;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

/**
 * Fork-only WorldGuard region flags.
 * <p>
 * Every flag defaults to {@code ALLOW}, so a server without these flags set
 * behaves exactly like upstream SmartSpawner.
 * <p>
 * WorldGuard requires custom flags to be registered before WorldGuard itself
 * enables, which means {@code onLoad()} of the plugin. That is the only place
 * where an upstream file has to be touched:
 * <pre>
 *   &#64;Override
 *   public void onLoad() {
 *       ForkFlags.register();
 *   }
 * </pre>
 * Everything else lives inside this package.
 */
public final class ForkFlags {

    public static final String USE = "smartspawner-use";
    public static final String PLACE = "smartspawner-place";
    public static final String BREAK = "smartspawner-break";
    public static final String STACK = "smartspawner-stack";
    public static final String SELL = "smartspawner-sell";
    public static final String GENERATE = "smartspawner-generate";

    private static boolean available;

    private static StateFlag useFlag;
    private static StateFlag placeFlag;
    private static StateFlag breakFlag;
    private static StateFlag stackFlag;
    private static StateFlag sellFlag;
    private static StateFlag generateFlag;

    private ForkFlags() {
    }

    /** Call from {@code SmartSpawner#onLoad()}. Safe when WorldGuard is absent. */
    public static void register() {
        if (Bukkit.getPluginManager().getPlugin("WorldGuard") == null) {
            return;
        }
        try {
            FlagRegistry registry = com.sk89q.worldguard.WorldGuard.getInstance().getFlagRegistry();
            useFlag = registerFlag(registry, USE);
            placeFlag = registerFlag(registry, PLACE);
            breakFlag = registerFlag(registry, BREAK);
            stackFlag = registerFlag(registry, STACK);
            sellFlag = registerFlag(registry, SELL);
            generateFlag = registerFlag(registry, GENERATE);
            available = useFlag != null;
        } catch (Throwable throwable) {
            available = false;
            Bukkit.getLogger().warning("[SmartSpawner/fork] WorldGuard flags not registered: " + throwable.getMessage());
        }
    }

    private static StateFlag registerFlag(FlagRegistry registry, String name) {
        StateFlag flag = new StateFlag(name, true);
        try {
            registry.register(flag);
            return flag;
        } catch (FlagConflictException conflict) {
            // Already present (plugin reload / another fork build) - reuse it.
            Flag<?> existing = registry.get(name);
            return existing instanceof StateFlag stateFlag ? stateFlag : null;
        }
    }

    public static boolean isAvailable() {
        return available && ForkConfig.get().isWorldGuardFlagsEnabled();
    }

    /** Player-bound query. Returns true when WorldGuard is absent or the flag allows. */
    public static boolean test(Player player, Location location, String flagName) {
        if (!isAvailable() || player == null || location == null || location.getWorld() == null) {
            return true;
        }
        if (player.isOp() || player.hasPermission("worldguard.region.bypass")) {
            return true;
        }
        StateFlag flag = flagOf(flagName);
        if (flag == null) {
            return true;
        }
        try {
            LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
            return query(location).queryState(adapt(location), localPlayer, flag) != StateFlag.State.DENY;
        } catch (Throwable throwable) {
            return true;
        }
    }

    /** Location-only query, used for loot generation where no player is involved. */
    public static boolean test(Location location, String flagName) {
        if (!isAvailable() || location == null || location.getWorld() == null) {
            return true;
        }
        StateFlag flag = flagOf(flagName);
        if (flag == null) {
            return true;
        }
        try {
            return query(location).queryState(adapt(location), (RegionAssociable) null, flag) != StateFlag.State.DENY;
        } catch (Throwable throwable) {
            return true;
        }
    }

    private static RegionQuery query(Location location) {
        RegionContainer container = com.sk89q.worldguard.WorldGuard.getInstance().getPlatform().getRegionContainer();
        return container.createQuery();
    }

    private static com.sk89q.worldedit.util.Location adapt(Location location) {
        return new com.sk89q.worldedit.util.Location(
                BukkitAdapter.adapt(location.getWorld()),
                location.getX(), location.getY(), location.getZ());
    }

    private static StateFlag flagOf(String name) {
        return switch (name) {
            case USE -> useFlag;
            case PLACE -> placeFlag;
            case BREAK -> breakFlag;
            case STACK -> stackFlag;
            case SELL -> sellFlag;
            case GENERATE -> generateFlag;
            default -> null;
        };
    }
}
